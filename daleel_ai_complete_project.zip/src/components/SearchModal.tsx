import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  X, 
  Loader2, 
  ArrowLeft, 
  Layers, 
  FileText, 
  Scale, 
  BookOpen, 
  Sparkles, 
  TrendingUp, 
  Clock, 
  Star, 
  CheckCircle,
  CornerDownLeft,
  Compass
} from 'lucide-react';
import { OptimizedImage } from './OptimizedImage.tsx';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  navigate: (path: string) => void;
}

interface SuggestionData {
  query: string;
  suggestions: string[];
  tools: any[];
  articles: any[];
  categories: any[];
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, navigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [suggestionsData, setSuggestionsData] = useState<SuggestionData>({
    query: '',
    suggestions: ['ChatGPT', 'Midjourney', 'Claude 3.5', 'توليد الصور', 'البرمجة بالأكواد', 'كتابة المحتوى'],
    tools: [],
    articles: [],
    categories: []
  });

  const inputRef = useRef<HTMLInputElement>(null);

  // Load initial suggestions or trending items on modal open
  useEffect(() => {
    if (!isOpen) {
      setSearchTerm('');
      setSelectedIndex(-1);
      return;
    }

    // Auto-focus input on open
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);

    // Fetch initial trending data
    const fetchInitialData = async () => {
      try {
        const res = await fetch('/api/search/suggestions');
        if (res.ok) {
          const data = await res.json();
          setSuggestionsData(data);
        }
      } catch (err) {
        console.error('Failed to fetch initial search suggestions', err);
      }
    };

    fetchInitialData();
  }, [isOpen]);

  // Real-time fetching as user types
  useEffect(() => {
    if (!isOpen) return;

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const queryParam = encodeURIComponent(searchTerm.trim());
        const res = await fetch(`/api/search/suggestions?q=${queryParam}`);
        if (res.ok) {
          const data = await res.json();
          setSuggestionsData(data);
          setSelectedIndex(-1);
        }
      } catch (e) {
        console.error('Search auto-suggestion error', e);
      } finally {
        setLoading(false);
      }
    }, 150);

    return () => clearTimeout(timer);
  }, [searchTerm, isOpen]);

  // Flattened navigable items for keyboard navigation
  const navigableItems = React.useMemo(() => {
    const items: { type: string; title: string; path: string }[] = [];
    
    // Tools
    suggestionsData.tools.forEach(t => {
      items.push({ type: 'tool', title: t.name, path: `/tools/${t.slug}` });
    });
    // Categories
    suggestionsData.categories.forEach(c => {
      items.push({ type: 'category', title: c.name, path: `/categories/${c.slug}` });
    });
    // Articles
    suggestionsData.articles.forEach(a => {
      items.push({ type: 'article', title: a.title, path: `/articles/${a.slug}` });
    });

    return items;
  }, [suggestionsData]);

  // Keyboard navigation listener
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev < navigableItems.length - 1 ? prev + 1 : 0));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev > 0 ? prev - 1 : navigableItems.length - 1));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (selectedIndex >= 0 && selectedIndex < navigableItems.length) {
          const selected = navigableItems[selectedIndex];
          navigate(selected.path);
          onClose();
        } else if (searchTerm.trim()) {
          // If typed query and hitting enter, navigate to tools directory with search filter
          navigate(`/ai-tools?search=${encodeURIComponent(searchTerm.trim())}`);
          onClose();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, selectedIndex, navigableItems, searchTerm, navigate, onClose]);

  // Highlight matched substrings in Arabic or English
  const highlightMatch = (text: string, queryText: string) => {
    if (!queryText.trim() || !text) return text;
    const parts = text.split(new RegExp(`(${queryText.trim()})`, 'gi'));
    return (
      <span>
        {parts.map((part, i) =>
          part.toLowerCase() === queryText.trim().toLowerCase() ? (
            <mark key={i} className="bg-indigo-100 text-indigo-900 rounded-sm px-0.5 font-bold">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </span>
    );
  };

  if (!isOpen) return null;

  const hasResults = 
    suggestionsData.tools.length > 0 || 
    suggestionsData.categories.length > 0 || 
    suggestionsData.articles.length > 0;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-start justify-center pt-12 sm:pt-20 px-3 sm:px-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200/90 overflow-hidden flex flex-col max-h-[85vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center gap-3 bg-white">
          <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center flex-shrink-0">
            <Search className="w-5 h-5 stroke-[2.2]" />
          </div>

          <input
            ref={inputRef}
            type="text"
            placeholder="اكتب للبحث الفوري في الأدوات، المقالات، والتصنيفات..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-transparent border-none outline-none text-slate-800 placeholder-slate-400 text-base sm:text-lg font-medium"
          />

          {loading ? (
            <Loader2 className="w-5 h-5 text-indigo-600 animate-spin flex-shrink-0" />
          ) : searchTerm ? (
            <button 
              onClick={() => {
                setSearchTerm('');
                inputRef.current?.focus();
              }} 
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
              title="مسح النص"
            >
              <X className="w-4 h-4" />
            </button>
          ) : null}

          <div className="hidden sm:flex items-center gap-1.5 pl-1">
            <kbd className="text-[11px] font-mono bg-slate-100 border border-slate-200 text-slate-500 px-2 py-0.5 rounded-md shadow-2xs">
              ESC
            </kbd>
          </div>
        </div>

        {/* Quick Suggestion Chips */}
        {suggestionsData.suggestions && suggestionsData.suggestions.length > 0 && (
          <div className="px-4 py-2.5 bg-slate-50/80 border-b border-slate-100 flex items-center gap-2 overflow-x-auto no-scrollbar">
            <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1 flex-shrink-0">
              <Sparkles className="w-3 h-3 text-indigo-500" />
              اقتراحات سريعة:
            </span>
            <div className="flex items-center gap-1.5">
              {suggestionsData.suggestions.map((sug, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setSearchTerm(sug);
                    inputRef.current?.focus();
                  }}
                  className="text-xs px-2.5 py-1 rounded-full bg-white border border-slate-200/80 text-slate-700 hover:border-indigo-300 hover:text-indigo-600 hover:bg-indigo-50/30 whitespace-nowrap transition-all shadow-2xs cursor-pointer"
                >
                  {sug}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Results / Auto-suggestions Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5">
          {!searchTerm.trim() && !hasResults ? (
            <div className="py-12 text-center text-slate-400 space-y-3">
              <Compass className="w-10 h-10 mx-auto text-indigo-300 stroke-1" />
              <div>
                <p className="text-sm font-bold text-slate-700">ابدأ الكتابة للبحث المباشر</p>
                <p className="text-xs text-slate-400 mt-1">ابحث عن اسم الأداة، مجال الاستخدام، أو مواضيع المقالات</p>
              </div>
            </div>
          ) : !hasResults && !loading ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <p className="text-base font-bold text-slate-800">لم نعثر على نتائج مطابقة لـ "{searchTerm}"</p>
              <p className="text-xs text-slate-400">تأكد من كتابة الكلمة بشكل صحيح، أو اضغط Enter لاستكشاف الدليل العام.</p>
              <button
                onClick={() => {
                  navigate(`/ai-tools?search=${encodeURIComponent(searchTerm.trim())}`);
                  onClose();
                }}
                className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 px-4 py-2 rounded-xl transition-colors cursor-pointer"
              >
                <span>عرض جميع الأدوات المطابقة</span>
                <ArrowLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <>
              {/* Section 1: Tools Auto-suggestions */}
              {suggestionsData.tools.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                      أدوات الذكاء الاصطناعي المقترحة ({suggestionsData.tools.length})
                    </h4>
                    {searchTerm.trim() && (
                      <button
                        onClick={() => {
                          navigate(`/ai-tools?search=${encodeURIComponent(searchTerm.trim())}`);
                          onClose();
                        }}
                        className="text-[11px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>عرض الكل في الدليل</span>
                        <ArrowLeft className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 gap-1.5">
                    {suggestionsData.tools.map((tool) => {
                      const itemPath = `/tools/${tool.slug}`;
                      const isSelected = selectedIndex >= 0 && navigableItems[selectedIndex]?.path === itemPath;

                      return (
                        <div
                          key={tool.id || tool.slug}
                          onClick={() => {
                            navigate(itemPath);
                            onClose();
                          }}
                          className={`p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                            isSelected 
                              ? 'bg-indigo-50/80 border-indigo-300 shadow-xs' 
                              : 'bg-white hover:bg-slate-50 border-slate-100 hover:border-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-xl overflow-hidden bg-slate-100 border border-slate-200/80 flex-shrink-0 flex items-center justify-center">
                              <OptimizedImage
                                src={tool.logo_url}
                                alt={tool.name}
                                width={40}
                                height={40}
                                fallbackText={tool.name}
                                className="w-full h-full object-cover"
                                containerClassName="w-full h-full"
                              />
                            </div>

                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="font-bold text-slate-900 text-sm truncate">
                                  {highlightMatch(tool.name, searchTerm)}
                                </span>
                                {tool.is_verified && (
                                  <CheckCircle className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
                                )}
                              </div>
                              <p className="text-xs text-slate-500 truncate leading-relaxed">
                                {tool.tagline}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0 mr-2">
                            {tool.rating && (
                              <div className="hidden sm:flex items-center gap-1 text-amber-500 text-xs font-bold bg-amber-50/80 px-2 py-0.5 rounded-md border border-amber-200/50">
                                <Star className="w-3 h-3 fill-current" />
                                <span>{Number(tool.rating).toFixed(1)}</span>
                              </div>
                            )}
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200/60">
                              {tool.pricing_type || 'Free'}
                            </span>
                            <ArrowLeft className="w-4 h-4 text-slate-300 group-hover:text-indigo-600" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Section 2: Categories */}
              {suggestionsData.categories.length > 0 && (
                <div className="space-y-2 pt-1">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-blue-600" />
                    التصنيفات ({suggestionsData.categories.length})
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {suggestionsData.categories.map((cat) => {
                      const itemPath = `/categories/${cat.slug}`;
                      const isSelected = selectedIndex >= 0 && navigableItems[selectedIndex]?.path === itemPath;

                      return (
                        <div
                          key={cat.id || cat.slug}
                          onClick={() => {
                            navigate(itemPath);
                            onClose();
                          }}
                          className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                            isSelected 
                              ? 'bg-blue-50 border-blue-300 text-blue-700' 
                              : 'bg-slate-50/70 hover:bg-white border-slate-200/70 hover:border-blue-200 text-slate-800'
                          }`}
                        >
                          <span className="truncate">{highlightMatch(cat.name, searchTerm)}</span>
                          <ArrowLeft className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Section 3: Articles & Educational Guides */}
              {suggestionsData.articles.length > 0 && (
                <div className="space-y-2 pt-1">
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
                    المقالات والأدلة التعليمية ({suggestionsData.articles.length})
                  </h4>
                  <div className="grid grid-cols-1 gap-1.5">
                    {suggestionsData.articles.map((art) => {
                      const itemPath = `/articles/${art.slug}`;
                      const isSelected = selectedIndex >= 0 && navigableItems[selectedIndex]?.path === itemPath;

                      return (
                        <div
                          key={art.id || art.slug}
                          onClick={() => {
                            navigate(itemPath);
                            onClose();
                          }}
                          className={`p-2.5 sm:p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                            isSelected 
                              ? 'bg-emerald-50 border-emerald-300 shadow-xs' 
                              : 'bg-white hover:bg-slate-50 border-slate-100 hover:border-slate-200'
                          }`}
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
                              <FileText className="w-4 h-4" />
                            </div>

                            <div className="min-w-0">
                              <h5 className="font-bold text-slate-900 text-xs sm:text-sm truncate">
                                {highlightMatch(art.title, searchTerm)}
                              </h5>
                              {art.excerpt && (
                                <p className="text-[11px] text-slate-500 truncate leading-relaxed">
                                  {art.excerpt}
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-shrink-0 mr-2">
                            {art.read_time && (
                              <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {art.read_time}
                              </span>
                            )}
                            <ArrowLeft className="w-3.5 h-3.5 text-slate-300" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer shortcuts & helper info */}
        <div className="bg-slate-50/90 px-4 py-3 border-t border-slate-100 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-mono text-slate-600 shadow-2xs">↑↓</kbd>
              للتنقل
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-mono text-slate-600 shadow-2xs">↵ Enter</kbd>
              للاختيار
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 bg-white border border-slate-200 rounded text-[10px] font-mono text-slate-600 shadow-2xs">ESC</kbd>
              للإغلاق
            </span>
          </div>

          <div className="text-[11px] font-semibold text-indigo-600 flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            <span>بحث فوري فائق السرعة • دليل الذكاء الاصطناعي</span>
          </div>
        </div>
      </div>
    </div>
  );
};
