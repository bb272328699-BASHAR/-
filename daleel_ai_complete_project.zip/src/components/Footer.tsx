import React from 'react';
import { Sparkles, Shield, Heart, ExternalLink, Mail } from 'lucide-react';

interface FooterProps {
  navigate: (path: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800/80">
          
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigate('/')}>
              <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/20">
                <Sparkles className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-xl tracking-tight text-white">دليل الذكاء الاصطناعي</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              المرجع المستقل الأول لتصنيف وتقييم ومقارنة أدوات ونماذج الذكاء الاصطناعي. نساعد رواد الأعمال والمطورين والمبدعين في اختيار الأداة المثالية لمهامهم اليومية.
            </p>
            <div className="flex items-center gap-3 pt-2 text-xs text-slate-400">
              <span className="inline-flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-full">
                <Shield className="w-3.5 h-3.5 text-emerald-400" />
                بيانات حقيقية موثقة
              </span>
              <span className="inline-flex items-center gap-1 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-full">
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                تحديثات 2026
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">استكشاف المنصة</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><button onClick={() => navigate('/advisor')} className="hover:text-indigo-400 transition-colors font-bold text-indigo-300 flex items-center gap-1">المستشار الذكي (AI Advisor) ✨</button></li>
              <li><button onClick={() => navigate('/prompts')} className="hover:text-indigo-400 transition-colors">مكتبة ومولد الأوامر (Prompts)</button></li>
              <li><button onClick={() => navigate('/stacks')} className="hover:text-indigo-400 transition-colors">حزم الأدوات التخصصية (Stacks)</button></li>
              <li><button onClick={() => navigate('/alternatives')} className="hover:text-indigo-400 transition-colors">دليل البدائل المجانية</button></li>
              <li><button onClick={() => navigate('/calculator')} className="hover:text-indigo-400 transition-colors">حاسبة العائد والتكاليف (ROI)</button></li>
              <li><button onClick={() => navigate('/comparisons')} className="hover:text-indigo-400 transition-colors">مقارنات الأدوات</button></li>
            </ul>
          </div>

          {/* Content & Resources */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">المحتوى والمصادر</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><button onClick={() => navigate('/articles')} className="hover:text-indigo-400 transition-colors">المقالات والتحليلات</button></li>
              <li><button onClick={() => navigate('/resources')} className="hover:text-indigo-400 transition-colors">الكتب والقوالب المجانية</button></li>
              <li><button onClick={() => navigate('/about')} className="hover:text-indigo-400 transition-colors">من نحن</button></li>
              <li><button onClick={() => navigate('/contact')} className="hover:text-indigo-400 transition-colors">تواصل معنا</button></li>
              <li><a href="/sitemap.xml" target="_blank" className="hover:text-indigo-400 transition-colors flex items-center gap-1">خريطة الموقع (Sitemap) <ExternalLink className="w-3 h-3" /></a></li>
            </ul>
          </div>

          {/* Policies & Compliance */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">السياسات والامتثال</h4>
            <ul className="space-y-2 text-sm text-slate-400">
              <li><button onClick={() => navigate('/editorial-policy')} className="hover:text-indigo-400 transition-colors">السياسة التحريرية ومنهجية التقييم</button></li>
              <li><button onClick={() => navigate('/privacy')} className="hover:text-indigo-400 transition-colors">سياسة الخصوصية وحماية البيانات</button></li>
              <li><button onClick={() => navigate('/terms')} className="hover:text-indigo-400 transition-colors">شروط وأحكام الاستخدام</button></li>
              <li><button onClick={() => navigate('/cookie-policy')} className="hover:text-indigo-400 transition-colors">سياسة ملفات تعريف الارتباط</button></li>
              <li><button onClick={() => navigate('/affiliate-disclosure')} className="hover:text-indigo-400 transition-colors">إفصاح الشفافية والروابط التابعة</button></li>
              <li><a href="/sitemap.xml" target="_blank" className="hover:text-indigo-400 transition-colors flex items-center gap-1">خريطة الموقع (Sitemap.xml) <ExternalLink className="w-3 h-3" /></a></li>
            </ul>
          </div>

        </div>

        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="space-y-1 text-center sm:text-right">
            <p>© 2026 منصة دليل الذكاء الاصطناعي (Daleel AI). جميع الحقوق محفوظة.</p>
            <p className="text-slate-400">النطاق الرسمي الموثق: <strong className="text-indigo-400 font-mono">daleel.ai</strong> | معتمد من قبل خبراء التقنية العرب</p>
          </div>
          <p className="flex items-center gap-1">
            صُمم بأعلى معايير الحرفية باللغة العربية لدعم المبتكرين العرب
          </p>
        </div>
      </div>
    </footer>
  );
};
