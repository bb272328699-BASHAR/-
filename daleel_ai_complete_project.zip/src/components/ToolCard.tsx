import React from 'react';
import { Star, CheckCircle, ExternalLink, ArrowLeft, Bookmark } from 'lucide-react';
import { Tool } from '../types.ts';
import { OptimizedImage } from './OptimizedImage.tsx';

interface ToolCardProps {
  tool: Tool;
  onSelect: (slug: string) => void;
  onCategoryClick?: (categorySlug: string) => void;
}

export const ToolCard: React.FC<ToolCardProps> = ({ tool, onSelect, onCategoryClick }) => {
  const getPricingBadge = (type: string) => {
    switch (type.toLowerCase()) {
      case 'free':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'freemium':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'paid':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'free trial':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      default:
        return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div 
      className="group relative flex flex-col justify-between bg-white rounded-2xl border border-slate-200/90 hover:border-indigo-300 shadow-sm hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-300 p-5 cursor-pointer"
      onClick={() => onSelect(tool.slug)}
    >
      <div>
        {/* Top Header: Logo, Name, Verification, Pricing badge */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 border border-slate-200/80 flex-shrink-0 flex items-center justify-center">
              <OptimizedImage
                src={tool.logo_url}
                alt={tool.name}
                width={48}
                height={48}
                fallbackText={tool.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                containerClassName="w-full h-full"
              />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-base text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {tool.name}
                </h3>
                {tool.is_verified && (
                  <span title="أداة معتمدة ومفحوصة">
                    <CheckCircle className="w-4 h-4 text-blue-500 flex-shrink-0" />
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex items-center gap-1 bg-amber-50/90 border border-amber-200/60 px-2 py-0.5 rounded-md text-amber-900 text-xs font-bold">
                  <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  <span>{tool.rating ? Number(tool.rating).toFixed(1) : '4.9'}</span>
                </div>
                {tool.review_count > 0 && (
                  <span className="text-[11px] text-slate-400 font-medium">({tool.review_count} تقييم)</span>
                )}
              </div>
            </div>
          </div>

          <span className={`text-xs font-semibold px-2.5 py-1 rounded-lg border ${getPricingBadge(tool.pricing_type)}`}>
            {tool.pricing_type}
          </span>
        </div>

        {/* Tagline */}
        <p className="text-slate-600 text-xs sm:text-sm line-clamp-2 leading-relaxed mb-4">
          {tool.tagline}
        </p>

        {/* Categories tags */}
        {Array.isArray(tool.categories) && tool.categories.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {tool.categories.slice(0, 2).map((cat) => (
              <button
                key={cat.id || cat.slug}
                onClick={(e) => {
                  e.stopPropagation();
                  if (onCategoryClick) onCategoryClick(cat.slug);
                }}
                className="text-[11px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-600 px-2 py-0.5 rounded-md transition-colors"
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Card Footer: Starting Price & CTA button */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 mt-auto">
        <div className="text-xs text-slate-500 font-medium">
          {tool.starting_price ? (
            <span>يبدأ من <strong className="text-slate-800 font-bold">{tool.starting_price}</strong></span>
          ) : (
            <span className="text-emerald-600 font-bold">متاح للتجربة</span>
          )}
        </div>

        <div className="flex items-center gap-1 text-xs font-bold text-indigo-600 group-hover:translate-x-[-2px] transition-transform">
          <span>التفاصيل</span>
          <ArrowLeft className="w-3.5 h-3.5" />
        </div>
      </div>
    </div>
  );
};
