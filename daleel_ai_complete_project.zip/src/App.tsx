import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { SearchModal } from './components/SearchModal.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { ToolsPage } from './pages/ToolsPage.tsx';
import { ToolDetailPage } from './pages/ToolDetailPage.tsx';
import { CategoriesPage } from './pages/CategoriesPage.tsx';
import { CategoryDetailPage } from './pages/CategoryDetailPage.tsx';
import { ReviewsPage } from './pages/ReviewsPage.tsx';
import { ComparisonsPage } from './pages/ComparisonsPage.tsx';
import { TutorialsPage } from './pages/TutorialsPage.tsx';
import { ArticlesPage } from './pages/ArticlesPage.tsx';
import { ResourcesPage } from './pages/ResourcesPage.tsx';
import { StaticPages } from './pages/StaticPages.tsx';
import { AdminLoginPage } from './pages/AdminLoginPage.tsx';
import { AdminDashboard } from './pages/AdminDashboard.tsx';
import { UserProfilePage } from './pages/UserProfilePage.tsx';
import { AIAdvisorPage } from './pages/AIAdvisorPage.tsx';
import { PromptsHubPage } from './pages/PromptsHubPage.tsx';
import { StacksPage } from './pages/StacksPage.tsx';
import { RoiCalculatorPage } from './pages/RoiCalculatorPage.tsx';
import { AlternativesPage } from './pages/AlternativesPage.tsx';
import { AuthModal } from './components/AuthModal.tsx';
import { CookieBanner } from './components/CookieBanner.tsx';
import { ScrollProgress } from './components/ScrollProgress.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { Tool, Category, Article, Comparison, Review, Tutorial } from './types.ts';
import { Loader2 } from 'lucide-react';
import { usePageTracking } from './hooks/usePageTracking.ts';
import { fetchAdSettings } from './components/AdSlot.tsx';
import { getSavedConsent } from './utils/consent.ts';

export default function App() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname || '/');
  const [searchOpen, setSearchOpen] = useState(false);

  // Google Analytics 4 automatic page view tracking on route changes
  usePageTracking(currentPath);

  // Admin session state
  const [adminToken, setAdminToken] = useState<string | null>(localStorage.getItem('daleel_admin_token'));
  const [adminUser, setAdminUser] = useState<any>(() => {
    const saved = localStorage.getItem('daleel_admin_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Global catalog states
  const [categories, setCategories] = useState<Category[]>([]);
  const [trendingTools, setTrendingTools] = useState<Tool[]>([]);
  const [popularTools, setPopularTools] = useState<Tool[]>([]);
  const [newTools, setNewTools] = useState<Tool[]>([]);
  const [latestReviews, setLatestReviews] = useState<Review[]>([]);
  const [latestComparisons, setLatestComparisons] = useState<Comparison[]>([]);
  const [latestTutorials, setLatestTutorials] = useState<Tutorial[]>([]);
  const [latestArticles, setLatestArticles] = useState<Article[]>([]);
  const [loadingInitial, setLoadingInitial] = useState(true);

  // Synchronize browser URL on internal navigation
  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  // Keyboard shortcut ⌘K or Ctrl+K for search
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  // Fetch initial catalog data from PostgreSQL
  useEffect(() => {
    let isMounted = true;

    async function fetchSafe(url: string) {
      try {
        const res = await fetch(url);
        if (!res.ok) return null;
        return await res.json();
      } catch (e) {
        console.warn(`Transient fetch issue for ${url}:`, e);
        return null;
      }
    }

    async function loadData() {
      try {
        const [homeData, catsData, revData, compData, tutData, artData] = await Promise.all([
          fetchSafe('/api/collections/home'),
          fetchSafe('/api/categories'),
          fetchSafe('/api/reviews'),
          fetchSafe('/api/comparisons'),
          fetchSafe('/api/tutorials'),
          fetchSafe('/api/articles'),
        ]);

        if (!isMounted) return;

        if (homeData) {
          setTrendingTools(Array.isArray(homeData?.trending) ? homeData.trending : []);
          setPopularTools(Array.isArray(homeData?.popular) ? homeData.popular : []);
          setNewTools(Array.isArray(homeData?.newest) ? homeData.newest : []);
        }
        if (catsData && Array.isArray(catsData)) {
          setCategories(catsData);
        }
        if (revData && Array.isArray(revData)) {
          setLatestReviews(revData);
        }
        if (compData && Array.isArray(compData)) {
          setLatestComparisons(compData);
        }
        if (tutData && Array.isArray(tutData)) {
          setLatestTutorials(tutData);
        }
        if (artData && Array.isArray(artData)) {
          setLatestArticles(artData);
        }
      } catch (err) {
        console.warn('Initial load handled safely:', err);
      } finally {
        if (isMounted) {
          setLoadingInitial(false);
        }
      }
    }

    loadData();

    return () => {
      isMounted = false;
    };
  }, []);

  // Google AdSense Auto-ads Initialization with Consent Mode awareness
  useEffect(() => {
    let unmounted = false;

    fetchAdSettings().then((settings) => {
      if (unmounted) return;
      const isAdsEnabled = settings?.ads_enabled === 'true' || settings?.ads_enabled === '1';
      const isAutoAdsEnabled = settings?.ads_auto_ads_enabled === 'true' || settings?.ads_auto_ads_enabled === '1' || settings?.ads_auto_ads_enabled === undefined;
      const isTestMode = settings?.ads_test_mode === 'true';
      const publisherId = settings?.ads_publisher_id;

      if (!isAdsEnabled || !isAutoAdsEnabled || isTestMode || !publisherId || publisherId === 'ca-pub-0000000000000000') {
        return;
      }

      const scriptId = 'google-adsense-script';
      let script = document.getElementById(scriptId) as HTMLScriptElement;

      if (!script) {
        script = document.createElement('script');
        script.id = scriptId;
        script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${publisherId}`;
        script.async = true;
        script.crossOrigin = 'anonymous';
        script.setAttribute('data-ad-client', publisherId);
        document.head.appendChild(script);
      } else if (!script.getAttribute('data-ad-client')) {
        script.setAttribute('data-ad-client', publisherId);
      }
    });

    return () => {
      unmounted = true;
    };
  }, []);

  const handleAdminLogin = (token: string, user: any) => {
    localStorage.setItem('daleel_admin_token', token);
    localStorage.setItem('daleel_admin_user', JSON.stringify(user));
    setAdminToken(token);
    setAdminUser(user);
    navigate('/admin');
  };

  const handleAdminLogout = () => {
    localStorage.removeItem('daleel_admin_token');
    localStorage.removeItem('daleel_admin_user');
    setAdminToken(null);
    setAdminUser(null);
    navigate('/admin/login');
  };

  // Router matching logic
  const renderRoute = () => {
    if (loadingInitial) {
      return (
        <div className="min-h-[70vh] flex flex-col items-center justify-center space-y-4">
          <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
          <p className="text-slate-600 font-bold text-base">جاري تحميل منصة دليل الذكاء الاصطناعي...</p>
        </div>
      );
    }

    // 1. Home
    if (currentPath === '/') {
      return (
        <HomePage
          categories={categories}
          trendingTools={trendingTools}
          popularTools={popularTools}
          newTools={newTools}
          latestReviews={latestReviews}
          latestComparisons={latestComparisons}
          latestTutorials={latestTutorials}
          latestArticles={latestArticles}
          navigate={navigate}
          openSearch={() => setSearchOpen(true)}
        />
      );
    }

    // 2. Tools list
    if (currentPath === '/ai-tools' || currentPath.startsWith('/ai-tools?')) {
      return <ToolsPage categories={categories} navigate={navigate} />;
    }

    const sanitizeSlug = (raw: string) => raw.split('?')[0].split('#')[0].replace(/\/$/, '');

    // 3. Tool Details: /tools/:slug or /tool/:slug
    if (currentPath.startsWith('/tools/') || currentPath.startsWith('/tool/')) {
      const slug = sanitizeSlug(currentPath.startsWith('/tools/') ? currentPath.replace('/tools/', '') : currentPath.replace('/tool/', ''));
      return <ToolDetailPage slug={slug} navigate={navigate} />;
    }

    // 4. Categories list: /categories
    if (currentPath === '/categories') {
      return <CategoriesPage navigate={navigate} />;
    }

    // 5. Category Details: /categories/:slug
    if (currentPath.startsWith('/categories/')) {
      const slug = sanitizeSlug(currentPath.replace('/categories/', ''));
      return <CategoryDetailPage slug={slug} navigate={navigate} />;
    }

    // 6. Reviews: /reviews or /reviews/:slug
    if (currentPath === '/reviews') {
      return <ReviewsPage navigate={navigate} />;
    }
    if (currentPath.startsWith('/reviews/')) {
      const slug = sanitizeSlug(currentPath.replace('/reviews/', ''));
      return <ReviewsPage navigate={navigate} reviewSlug={slug} />;
    }

    // 7. Comparisons: /comparisons or /comparisons/:slug
    if (currentPath === '/comparisons' || currentPath.startsWith('/comparisons?')) {
      const search = currentPath.includes('?') ? currentPath.split('?')[1] : window.location.search;
      const params = new URLSearchParams(search);
      const tool1 = params.get('tool1') || undefined;
      const tool2 = params.get('tool2') || undefined;
      const tool3 = params.get('tool3') || undefined;
      return <ComparisonsPage navigate={navigate} initialToolA={tool1} initialToolB={tool2} initialToolC={tool3} />;
    }
    if (currentPath.startsWith('/comparisons/')) {
      const slug = sanitizeSlug(currentPath.replace('/comparisons/', ''));
      return <ComparisonsPage navigate={navigate} comparisonSlug={slug} />;
    }

    // 8. Tutorials: /tutorials or /tutorials/:slug
    if (currentPath === '/tutorials') {
      return <TutorialsPage navigate={navigate} />;
    }
    if (currentPath.startsWith('/tutorials/')) {
      const slug = sanitizeSlug(currentPath.replace('/tutorials/', ''));
      return <TutorialsPage navigate={navigate} tutorialSlug={slug} />;
    }

    // 9. Articles: /articles or /articles/:slug
    if (currentPath === '/articles') {
      return <ArticlesPage navigate={navigate} />;
    }
    if (currentPath.startsWith('/articles/')) {
      const slug = sanitizeSlug(currentPath.replace('/articles/', ''));
      return <ArticlesPage navigate={navigate} articleSlug={slug} />;
    }

    // 10. Resources: /resources
    if (currentPath === '/resources') {
      return <ResourcesPage />;
    }

    // 11. AI Advisor: /advisor
    if (currentPath === '/advisor') {
      return <AIAdvisorPage navigate={navigate} />;
    }

    // 12. Prompts Hub: /prompts
    if (currentPath === '/prompts') {
      return <PromptsHubPage navigate={navigate} />;
    }

    // 13. AI Stacks: /stacks
    if (currentPath === '/stacks') {
      return <StacksPage navigate={navigate} />;
    }

    // 14. ROI Calculator: /calculator
    if (currentPath === '/calculator') {
      return <RoiCalculatorPage navigate={navigate} />;
    }

    // 15. Alternatives Directory: /alternatives
    if (currentPath === '/alternatives') {
      return <AlternativesPage navigate={navigate} />;
    }

    // 16. User Profile & Bookmarks
    if (currentPath === '/profile') {
      return <UserProfilePage navigate={navigate} />;
    }

    // 12. Static Pages
    if (currentPath === '/about') return <StaticPages type="about" navigate={navigate} />;
    if (currentPath === '/contact') return <StaticPages type="contact" navigate={navigate} />;
    if (currentPath === '/privacy') return <StaticPages type="privacy" navigate={navigate} />;
    if (currentPath === '/terms') return <StaticPages type="terms" navigate={navigate} />;
    if (currentPath === '/affiliate-disclosure') return <StaticPages type="affiliate" navigate={navigate} />;
    if (currentPath === '/editorial-policy') return <StaticPages type="editorial" navigate={navigate} />;
    if (currentPath === '/cookie-policy') return <StaticPages type="cookies" navigate={navigate} />;

    // 13. Admin Routes
    if (currentPath === '/admin/login') {
      return <AdminLoginPage onLoginSuccess={handleAdminLogin} navigate={navigate} />;
    }
    if (currentPath === '/admin') {
      if (!adminToken) {
        return <AdminLoginPage onLoginSuccess={handleAdminLogin} navigate={navigate} />;
      }
      return <AdminDashboard navigate={navigate} onLogout={handleAdminLogout} token={adminToken} />;
    }

    // 14. 404 Fallback
    return (
      <div className="max-w-xl mx-auto py-28 text-center space-y-4">
        <span className="text-6xl font-black text-indigo-600 block">404</span>
        <h2 className="text-2xl font-bold text-slate-900">الصفحة المطلوبة غير موجودة</h2>
        <p className="text-slate-500 text-sm">تأكد من صحة الرابط أو تصفح الأقسام الرئيسية مباشرة.</p>
        <button
          onClick={() => navigate('/')}
          className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-6 py-2.5 rounded-xl text-sm transition-colors shadow-sm"
        >
          العودة للرئيسية
        </button>
      </div>
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/50 text-slate-900 font-sans antialiased selection:bg-indigo-500 selection:text-white" dir="rtl">
      {/* Subtle Scroll Progress Indicator */}
      <ScrollProgress currentPath={currentPath} />

      {/* Global Navbar */}
      <Navbar
        currentPath={currentPath}
        navigate={navigate}
        openSearch={() => setSearchOpen(true)}
        openAdmin={() => navigate(adminToken ? '/admin' : '/admin/login')}
        isAdminLoggedIn={!!adminToken}
      />

      {/* Main Routed Page Content wrapped in ErrorBoundary with route key */}
      <main className="flex-1">
        <ErrorBoundary key={currentPath} navigate={navigate}>
          {renderRoute()}
        </ErrorBoundary>
      </main>

      {/* Global Footer */}
      <Footer navigate={navigate} />

      {/* Global Search Modal with widget ErrorBoundary */}
      <ErrorBoundary isWidget widgetName="نافذة البحث">
        <SearchModal
          isOpen={searchOpen}
          onClose={() => setSearchOpen(false)}
          navigate={navigate}
        />
      </ErrorBoundary>

      {/* Global Authentication Modal */}
      <AuthModal />

      {/* Global Cookie Compliance Banner */}
      <CookieBanner navigate={navigate} />
    </div>
  );
}
