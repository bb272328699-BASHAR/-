/**
 * Dynamic SEO, OpenGraph, Canonical URL & Schema.org Management Utility
 */

export interface SEOConfig {
  title: string;
  description: string;
  keywords?: string;
  canonicalUrl?: string;
  ogImage?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogType?: 'website' | 'article' | 'product';
  robots?: string;
  structuredData?: Record<string, any> | null;
}

function setMetaTag(name: string, content: string, isProperty = false) {
  if (!content) return;
  const attribute = isProperty ? 'property' : 'name';
  let element = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement | null;
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, name);
    document.head.appendChild(element);
  }
  element.setAttribute('content', content);
}

function setCanonical(url: string) {
  if (!url) return;
  let element = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!element) {
    element = document.createElement('link');
    element.setAttribute('rel', 'canonical');
    document.head.appendChild(element);
  }
  element.setAttribute('href', url);
}

function setJsonLd(data: Record<string, any> | null) {
  const existing = document.querySelector('script[data-type="dynamic-seo-jsonld"]');
  if (existing) {
    existing.remove();
  }
  if (!data) return;

  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.setAttribute('data-type', 'dynamic-seo-jsonld');
  script.text = JSON.stringify(data);
  document.head.appendChild(script);
}

export function updateDocumentSEO(config: SEOConfig) {
  const fullTitle = config.title.includes('دليل') ? config.title : `${config.title} | دليل الذكاء الاصطناعي`;
  
  // Document Title
  document.title = fullTitle;

  // Primary Standard Meta Tags
  setMetaTag('description', config.description);
  if (config.keywords) {
    setMetaTag('keywords', config.keywords);
  }
  setMetaTag('robots', config.robots || 'index, follow');

  // Canonical URL
  const canonical = config.canonicalUrl || (typeof window !== 'undefined' ? window.location.href : '');
  if (canonical) {
    setCanonical(canonical);
  }

  // OpenGraph (Facebook / WhatsApp / LinkedIn / Slack)
  const ogTitle = config.ogTitle || fullTitle;
  const ogDesc = config.ogDescription || config.description;
  const ogImg = config.ogImage || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&h=630&auto=format&fit=crop&q=80';
  
  setMetaTag('og:site_name', 'دليل الذكاء الاصطناعي | Daleel AI', true);
  setMetaTag('og:title', ogTitle, true);
  setMetaTag('og:description', ogDesc, true);
  setMetaTag('og:image', ogImg, true);
  setMetaTag('og:url', canonical, true);
  setMetaTag('og:type', config.ogType || 'website', true);

  // Twitter Cards
  setMetaTag('twitter:card', 'summary_large_image');
  setMetaTag('twitter:site', '@DaleelAI');
  setMetaTag('twitter:title', ogTitle);
  setMetaTag('twitter:description', ogDesc);
  setMetaTag('twitter:image', ogImg);

  // JSON-LD Structured Data
  if (config.structuredData) {
    setJsonLd(config.structuredData);
  }
}
